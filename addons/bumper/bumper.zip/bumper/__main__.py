import bumper

if __name__ == "__main__":
    bumper.main()